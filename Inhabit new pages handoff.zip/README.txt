Inhabit: Sell and Buy + Need Advice? pages (approved 10.29.26)

mockups/    The approved designs at 1440px wide. These are the target.
photos/     Three new photos for assets/photos (field sign and two listing photos from Becky's Drive folders).
reference/  The HTML the mockups were drawn from. Use it for exact copy, layout and spacing values.
            It is a drawing aid, not production code: image paths point at a local img/ folder,
            and the sans font in the drawing is the site's own stack.
